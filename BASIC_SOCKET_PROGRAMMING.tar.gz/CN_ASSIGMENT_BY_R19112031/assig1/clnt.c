/*required header files*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <time.h> 
#include<netdb.h>
#include<ctype.h>

/*driver programm*/
int main(int argc, char const *argv[])
{
	/*declaration of variable*/
	struct sockaddr_in serverAddr;
	struct hostent *server;
    int sockfd,sock, portno;
    
	system("clear");

     if(argc!=3)//checking command line argument
     {
     	printf("use %s <hostname> <port> ",argv[0]);
     	exit(0);
     }
     /*creating the socket*/
     sockfd = socket(AF_INET,SOCK_STREAM,0);
     if(sockfd<0)
     	perror("\nError opening socket.");

     portno = atoi(argv[2]);//port number
     /*assing the proper protocol to structure member*/
     serverAddr.sin_family = AF_INET;
     server = gethostbyname(argv[1]);//geting host in string formate
     serverAddr.sin_port = htons(portno);
    /*checking host valid or not*/
    if(server == NULL)
      printf("invalid address");
    /*try to connect to server*/
    sock = connect(sockfd,(struct sockaddr *)&serverAddr,sizeof(serverAddr));
    /*checking connection done or not*/
    if(sock <0)
      printf("error to connect...");
     char buff[80];
     memset(buff,'\0',sizeof(buff));//clear buff array
     recv(sockfd,buff,sizeof(buff),0);//receving the day and time
     printf("%s\n",buff );//print the receving object

      close(sockfd);//closing socket  

	return 0;
}
