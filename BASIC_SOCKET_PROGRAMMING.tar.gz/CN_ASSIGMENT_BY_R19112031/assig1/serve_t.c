/*required header files*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <time.h> 

/*driver code*/
int main(int argc, char const *argv[])
{
    /*declaration of variable*/	
	struct sockaddr_in serverAddr,clintAddr;
	int sockfd,new_sock, portno;
    
	system("clear");
     
     if(argc!=2) // code for checking commandline argument
     {
     	printf("use %s <port>",argv[0]);
     	exit(0);
     }
     
     sockfd = socket(AF_INET,SOCK_STREAM,0);//creating socket
     if(sockfd<0)
     	perror("\nError opening socket.");
     else
       printf("socket created.");

     portno = atoi(argv[1]); // port number

     /*assing value to structure member*/
     serverAddr.sin_family = AF_INET;
     serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
     serverAddr.sin_port = htons(portno);
     
     /*bind created socket*/
     if(bind(sockfd,(struct sockaddr *)&serverAddr,sizeof(serverAddr))<0){
     	perror("\nerror to bind.");
     	exit(0);
     }
     else
      printf("\nbinding succesfully");

     /*listening clients connection*/
    if(listen(sockfd,5)<0)
	{
		printf("Error in listen");
		exit(0);
	}
	else
		printf("Listening...\n");
    /*accept client connection*/
    int clintL = sizeof(clintAddr); 
    new_sock = accept(sockfd,(struct sockaddr *)&clintAddr,&clintL);
      if(new_sock<0)
         perror("error to connection");
      char buff[80]; 
      time_t t;//to get current day time
      time(&t);
      strcpy(buff,ctime(&t)); 
      send(new_sock,buff,strlen(buff),0);//sending data and time in string formate
	
	return 
0;
}
