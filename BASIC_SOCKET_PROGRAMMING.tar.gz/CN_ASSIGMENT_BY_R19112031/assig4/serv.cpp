/*required headers files*/
using namespace std;
#include<iostream>
#include<string>
#include<cstdio>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>

/*server class initilizing and creating socket*/
class server
{
	/*declaration of variable*/
   private :
     struct sockaddr_in addr;
     int sockfd,child;
     int ch,p;
   public :
      
      server(string port){//public server constructor
        sockfd = 0 ;
        init(port);
      }  
       /*init() to initilize socket*/  
      void init(string port){

      	  if((sockfd = socket(AF_INET,SOCK_STREAM,0))<0)//creating socket
      	  {
      	  	perror("error to opening socket");
      	  	exit(0);
      	  }
          
          /*assing structure member value*/
      	  addr.sin_family = AF_INET;
      	  addr.sin_port = htons(atoi(port.c_str()));
      	  addr.sin_addr.s_addr = htonl(INADDR_ANY);
           
           /*bind create socket*/ 
      	  if(bind(sockfd,(struct sockaddr *)&addr,sizeof(addr))<0)
      	  {
      	  	perror("error to bind socket");
      	  	exit(0);
      	  }
            /*listening the client connection*/
      	  if(listen(sockfd,5)<0)
      	  {
      	  	perror("error to listening .");
      	  	exit(0);
      	  }
      	  else
      	  	cout<<"\nlistening ..."<<endl;

          socklen_t len = sizeof(addr);
           /*accepting the client connection*/
      	  if((child = accept(sockfd,(struct sockaddr *)&addr,&len))<0)
      	  {
              perror("connecting error");
              exit(0);   
      	  }
      	  else
      	  	cout<<"\nconnecting ..."<<endl;

          connecting();//is for perform sending & receving object
      }

      void connecting()
      {
      	     while(true)
      	     {
      	     	/*reading the choise from client*/
                 if(read(child,&ch,sizeof(int))<0)
              {
              	perror("eror to receving no.");
              } 

              switch(ch){
              	/*case 1 for calculating square for receving number*/
                case 1 :if(read(child,&p,sizeof(int))>0)
                       {
                  	     p*=p;
                  	     if(write(child,&p,sizeof(p))<0)//sending square of number
                  	  	 perror("sending error");
                       }
                       break;  
                /*case 2 for calculating square & square in binary form*/
                case 2:
                  if(read(child,&p,sizeof(int))>0)
                  {
                  	    
                  	  p*=p;
                  	  string b = bin(p);

                  	  if(write(child,&p,sizeof(int))<0)//sending the square of number
                  	  	 perror("sending error");
                  	  if(write(child,b.c_str(),b.size())<0)//sending the square of number in binary form
                  	  	 perror("sending error");
                  	  b.clear();	 	
                  }	
                  break;
                /*case 3 for exit the client connection*/
                case 3: close(child);
                        break;	
              }
      	     }  
                           
      }

      string bin(int no)//calculating binary form of number
      {
      	  string bin ;
      	  
      	  if(no<=0)
      	  	return string("0");

      	  while(no>0)
      	  {
      	  	int n = no%2;
      	  	bin.insert(0,to_string(n));
      	  	no/=2;
      	  }

         return bin;
      }
};

int main(int argc, char const *argv[])
{
	
	if(argc!=2) //checking command line argument
	{
		cout<<"use "<<argv[0]<<" <port>";
		exit(0);
	}

	server s(argv[1]);//creating server class object and process further

return 0;
}