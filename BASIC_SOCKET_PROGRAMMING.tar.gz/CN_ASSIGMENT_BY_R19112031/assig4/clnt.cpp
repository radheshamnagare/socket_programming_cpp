/*required header files*/
using namespace std;
#include<iostream>
#include<string>
#include<cstdio>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<netdb.h>

/*connecting() initilize & create socket*/
void connecting(string port,string host)
{
	/*declaration of variable*/
     struct sockaddr_in addr;
     struct hostent *hostname;
     int sockfd;
     int ch,p;
     char buff[80];
     
     /*creating socket*/
     if((sockfd = socket(AF_INET,SOCK_STREAM,0))<0)
     {
     	perror("error opening socket");
     	exit(0);
     }
     /*assing proper protocols to structure member*/
     addr.sin_family = AF_INET;
     addr.sin_port = htons(atoi(port.c_str()));
     hostname = gethostbyname(host.c_str());//valid hostname in string formate
     /*checking hostname is valid or not*/ 
     if(hostname == NULL)
     {
     	perror("error invalid host");
     	exit(0);
     }
     /*try to connect connection server*/
     if(connect(sockfd,(struct sockaddr *)&addr,sizeof(addr))<0)
     {
     	perror("error to connecting");
     	exit(0);
     }
          /*now start to perform sending and receving object*/
        while(true)
        {
        	/*choises*/
        	cout<<"\n1-find square\n2-find square & binary square\n3-exit"<<endl;
        	cout<<"\nEnter the choise :";
        	cin>>ch;
            memset(buff,'\0',sizeof(buff));//clear the buffer 
        	   switch(ch)
        	   {
        	   	  /*case 1 for getting square of number*/
        	   	  case 1: cout<<"\nEnter the no :";
        	   	          cin>>p;
        	   	          if(write(sockfd,&ch,sizeof(int))>0)//sending the choise
        	   	          {
        	   	          	  if(write(sockfd,&p,sizeof(int))>0)
        	   	          	  {
        	   	          	  	if(read(sockfd,&p,sizeof(int))>0)//receving the square of number
        	   	          	  		cout<<"\nResult :"<<p;
        	   	          	  }

        	   	          } 
        	   	          else
        	   	          	perror("error to sending");

        	   	          break;
        	   	  /*case 2 for getting square of number & getting square of num in binary form*/
        	   	  case 2: cout<<"\nEnter the no :";
        	   	          cin>>p;
        	   	          if(write(sockfd,&ch,sizeof(int))>0)//sending the choise
        	   	          {
        	   	          	  if(write(sockfd,&p,sizeof(int))>0)//sending the number
        	   	          	  {
        	   	          	  	if(read(sockfd,&p,sizeof(int))>0)//receving the square of number
        	   	          	  		cout<<"\nResult :"<<p;
        	   	          	  	if(read(sockfd,buff,sizeof(buff))>0)//receving the square of num in binary formate
        	   	          	  		cout<<"\nResult :"<<buff<<endl;
        	   	          	  }

        	   	          } 
        	   	          else
        	   	          	perror("error to sending");
        	   	          break;
                  /*case 3 for exit the connection*/  
        	   	  case 3:  close(sockfd);
        	   	           exit(0);


        	   }
        }
}

int main(int argc, char const *argv[])
{
   
   system("clear");

   if(argc!=3)//checking command line argument
   {
   	 cout<<" use "<<argv[0]<<" <port> <host>";
   	 exit(0);
   }	

   connecting(argv[1],argv[2]);//calling connecting() with port & host

return 0;
}