/*required header files*/
using namespace std;
#include <iostream>
#include<string>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include<netdb.h>

/*server class for perform basic server socket operation*/
class server
{
   /*declaration of variable*/
   private:
      sockaddr_in addr;
      int sockfd,child;   
   
   public :
         /*construtor of server class for initilizing & calling other function*/
         server(string port)
         {
          sockfd =0;
          init(port);
         }
         /*init() for creating & initilization of socket*/
         void init(string port)
         {
            /*creating socket*/
            if((sockfd = socket(AF_INET,SOCK_STREAM,0))<0)
            {
              perror("error to creating socket...");
              exit(0);
            }
            else
              cout<<"\nsocket succesfully created"<<endl;
            /*assing the proper protocol to server*/
            addr.sin_family = AF_INET;
            addr.sin_port = htons(atoi(port.c_str()));
            addr.sin_addr.s_addr = htonl(INADDR_ANY);
            /*bind the created socket*/
            if(bind(sockfd,(struct sockaddr *)&addr,sizeof(addr))<0)
            {
              perror("error to bind.");
              exit(0);
            }
            /*listening the client connection*/
             if(listen(sockfd,5)<0)
             {
              perror("error to listen");
              exit(0);
             }
             else
              cout<<"\nlistening ..."<<endl;
             /*accept the client connection*/
              socklen_t len = sizeof(addr);
             if((child = accept(sockfd,(struct sockaddr *)&addr,&len))<0)
             {
              perror("error to connect");
              exit(0);
             } 

             connect();//connect() for basic sending & receiving object
         }
          /*connect() for send & receiving object*/
         void connect()
         {
            while(true)
            {
               int ch,p,q,r;
               ch=p=q=r=0;
                /*reading the choise*/
                 if(read(child,&ch,sizeof(int))<0)
                 {
                  perror("error to reading");
                  exit(0);
                 }
                   /*case 1 for calculating addition of number*/
                   if(ch == 1)
                   {
                      if(read(child,&p,sizeof(int))<0)
                       perror("error to reading");
                      if(read(child,&q,sizeof(int))<0)
                       perror("error to reading");

                      r=p+q;
                      if(write(child,&r,sizeof(int))<0)
                       perror("error to sending");             
                   }
                   /*case 2 for calculating subtration of number*/
                   else if(ch == 2)
                   {
                      if(read(child,&p,sizeof(int))<0)
                       perror("error to reading");
                      if(read(child,&q,sizeof(int))<0)
                       perror("error to reading");

                      r=p-q;
                      if(write(child,&r,sizeof(int))<0)
                       perror("error to sending");
                   }
                   /*case 3 for calculating negative of number*/
                   else if(ch == 3)
                   {
                      if(read(child,&p,sizeof(int))<0)
                       perror("error to reading");
                    
                      r=p*(-1);
                      if(write(child,&r,sizeof(int))<0)
                       perror("error to sending");
                   }
                   /*case 4 for closing connection*/
                   else if(ch == 4)
                   {
                      close(child);
                      close(sockfd);
                      exit(0);
                   }
            }
         }
};
/*driver programm*/
int main(int argc, char const *argv[])
{
  
  system("clear");
     if(argc!=2)//checking command line argument
     {
       cout<<"use "<<argv[0]<<" <port>";
       exit(0);
     }
    server s(argv[1]);// try to accept server connection 

  return 0;
}