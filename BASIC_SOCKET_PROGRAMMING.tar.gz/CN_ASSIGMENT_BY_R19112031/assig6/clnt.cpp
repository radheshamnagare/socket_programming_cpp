/*required header files*/
using namespace std;
#include <iostream>
#include<string>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include<netdb.h>

/*connecting() for initilize & create socket*/
void connecting(string port,string host)
{
    /*declaration of variable*/
	struct sockaddr_in addr;
	struct hostent *hostname;
	int sockfd;
	int ch,p,q,r;

    /*creating the socket*/
	if((sockfd = socket(AF_INET,SOCK_STREAM,0))<0)
	{
		perror("error to opening socket");
		exit(0);
	}
    /*assing proper protocol to structure member*/
	addr.sin_family = AF_INET;
	addr.sin_port = htons(atoi(port.c_str())); //port no
    hostname = gethostbyname(host.c_str()); // host name in string formate
    /*checking hostname is valid or not */
    if(hostname == NULL)
    {
    	perror("invalid host");
    	exit(0);
    }
     /*try to connect to server also checking connection done or not*/
    if(connect(sockfd,(struct sockaddr *)&addr,sizeof(addr))<0)
    {
    	perror("connection error");
    	exit(0);
    }
    /*to perform basic operation like receving & sending data*/
    while(true)
    {
        /*choises*/
    	cout<<"\n1-Add\n2-Sub\n3-Negative\n4-exit";
    	cout<<"\nEnter the choise";
    	cin>>ch;//getting choise

    	     switch(ch)
    	     {
                /*case 1 & 2 perform addition and subtraction of given number*/
    	     	case 1: case 2:
    	     	       cout<<"\nEnter the two no :";
    	     	       cin>>p>>q;
    	     	       if(write(sockfd,&ch,sizeof(int))<0)//send choise to server
    	     	       	perror("error to send");
    	     	       if(write(sockfd,&p,sizeof(int))<0)//send number to server
    	     	       	perror("error to send");
    	     	       if(write(sockfd,&q,sizeof(int))<0)//send number to server
    	     	       	perror("error to send");
    	     	       /*reading result from server*/
    	     	       if(read(sockfd,&r,sizeof(int))<0)
    	     	       	perror("error to receving");
    	     	       else
    	     	       	cout<<"\nResult :"<<r;
    	     	       break;
                /*case 3 for getting negative of number*/
    	     	case 3: cout<<"\nEnter the no :";
    	     	        cin>>p;
    	     	        if(write(sockfd,&ch,sizeof(int))<0)//senfing choise
    	     	       	perror("error to send");       
    	     	        if(write(sockfd,&p,sizeof(int))<0)//sending the number
    	     	       	perror("error to send");

    	     	        if(read(sockfd,&r,sizeof(int))<0)//reading the result from server
    	     	       	perror("error to receving");
    	     	        else
    	     	       	cout<<"\nResult :"<<r;
    	     	        break;
                /*case 4 for exit the connection*/
    	     	case 4: if(write(sockfd,&ch,sizeof(int))<0)
    	     	       	perror("error to send"); 
    	     	       	close(sockfd);
    	     	       	exit(0);


    	     }
    }
}
/*driver code*/
int main(int argc, char const *argv[])
{
	system("clear");

    if(argc!=3)//checking command line argument
    {
    	cout<<"use "<<argv[0]<<" <port> <host>";
    	exit(0);
    }

    connecting(argv[1],argv[2]); // try to connecting connection with port and host
return 0;
}