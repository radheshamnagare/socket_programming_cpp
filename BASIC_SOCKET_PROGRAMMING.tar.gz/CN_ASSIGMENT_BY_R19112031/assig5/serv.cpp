/*required header files*/
using namespace std;
#include <iostream>
#include<string>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include<netdb.h>
#include<cmath>
/*server class for initilizing and creating socket*/
class server
{
   /*declaration of variable*/
   private :
     sockaddr_in addr;
     int sockfd,no,ch,new_sock;

   public :
   
      server(string port)//server construtor
      {
      	no = 0;
      	ch = 0;
      	sockfd = 0;
      	init(port);
      }  
       /*init() for creating socket*/    
      void init(string port)
      {
            /*creating socket*/
            if((sockfd = socket(AF_INET,SOCK_STREAM,0))<0)
            {
            	perror("error opening socket");
            	exit(0);
            }
            else
            	cout<<"\nsocket succesfuly created.";
            /*assing the proper protocol to structure member*/
            addr.sin_family = AF_INET;
            addr.sin_addr.s_addr = htonl(INADDR_ANY);
            addr.sin_port = htons(atoi(port.c_str()));
             /*bind the created socket*/
            if(bind(sockfd,(struct sockaddr *)&addr,sizeof(addr))<0)
            {
            	perror("error to bind.");
            	exit(0);
            }
            /*listening the client connection*/
            if(listen(sockfd,5)<0)
            {
            	perror("error to listen");
            	exit(0);
            }
            else
            	cout<<"\nlistening..."<<endl;

           socklen_t len = sizeof(addr);
             /*accept the client connection*/   
            if((new_sock = accept(sockfd,(struct sockaddr *)&addr,&len))<0)
            {
            	perror("error to connecting...");
            	exit(0);
            } 

            if(read(new_sock,&no,sizeof(int))<0)//reading the number
            {
            	perror("eror to receving");
            	exit(0);
            }

            if(read(new_sock,&ch,sizeof(int))<0)//reading the choise
            {
            	perror("eror to receving");
            	exit(0);
            }
            /*case 1 for calculating square of number*/
            if(ch == 1)
            {     int res = no*no;
                  if(write(new_sock,&res,sizeof(int))<0)
                  	perror("error to sending");

                  
            }
            /*case 2 for calculating the cube of number*/
            else if(ch == 2)
            {
                   int res = no*no*no;
                   if(write(new_sock,&res,sizeof(int))<0)
                   	 perror("error to sending");

                   
            }

      }


};
/*driver code*/
int main(int argc, char const *argv[])
{
	system("clear");

	if(argc!=2)//checking the command line argument
	{
		cout<<"use "<<argv[0]<<" <port>";
		exit(0);
	}

	server s(argv[1]);//try to connect server

return 0;
}