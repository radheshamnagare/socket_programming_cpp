/*required header files*/
using namespace std;
#include <iostream>
#include<string>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include<netdb.h>

/*driver code*/
int main(int argc, char const *argv[])
{
	if(argc!=3)//checking the cammand line argument
	{
        cout<<"use "<<argv[0]<<" <port> <host>";
        exit(0);
	}
   /*declaration of variable*/
   struct sockaddr_in addr;
   struct hostent *host;
   int sockfd;
   char buff[80];
   /*creating the socket*/
   if((sockfd = socket(AF_INET,SOCK_STREAM,0))<0)
   {
   	perror("\nerror opening socket.");
   	exit(0);
   }
  /*assing the proper protocol to structure member*/
   addr.sin_family = AF_INET;
   addr.sin_port = htons(atoi(argv[1])); // port
   host = gethostbyname(argv[2]);//hostname in string formate
    /*checking the hostname is valid or not*/
   if(host==NULL)
   {
   	perror("invalid host");
   	exit(0);
   }
     /*try to connect server*/
    if(connect(sockfd,(struct sockaddr *)&addr,sizeof(addr))<0)
    {
    	perror("connecting error ");
    	exit(0);
    }
    else
    	cout<<"\nconnecting..."<<endl;

     

    int ch;
    int p,res;
   /*choises*/
    cout<<"\n1-square\n2-cube";
    cout<<"\nEnter the choise :";
    cin>>ch;
    
    cout<<"\nEnter no:";
    cin>>p;

    if(write(sockfd,&p,sizeof(int))<0)//sending number
    {
    	perror("error to sending");
    	exit(0);
    }
    if(write(sockfd,&ch,sizeof(int))<0)//sending choise
    {
    	perror("error to sending");
    	exit(0);
    }
   

    if(read(sockfd,&res,sizeof(int))<0)//reading the result
    {
    	perror("error to receving...");
    	exit(0);
    }
    else
    {
    	cout<<"\nResult :"<<res;

    }

close(sockfd);//close socket
return 0;
}