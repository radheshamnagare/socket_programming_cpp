/*required header files*/
using namespace std;
#include <iostream>
#include<string>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include<netdb.h>

/*driver code*/
int main(int argc, char const *argv[])
{
	
	if(argc!=3)//checking command line argument
	{
        cout<<"use "<<argv[0]<<" <port> <host>";
        exit(0);
	}
   /*declaration of variable*/
   struct sockaddr_in addr;
   struct hostent *host;
   int sockfd;
   char buff[80];
   /*creating socket*/
   if((sockfd = socket(AF_INET,SOCK_STREAM,0))<0)
   {
   	perror("\nerror opening socket.");
   	exit(0);
   }
  /*assing the proper protocol to structure member*/
   addr.sin_family = AF_INET;
   addr.sin_port = htons(atoi(argv[1]));
   host = gethostbyname(argv[2]);//getting string formate hostname
   /*checking host is valid or not*/
   if(host==NULL)
   {
   	perror("invalid host");
   	exit(0);
   }
     /*try to connect server and checking connection*/
    if(connect(sockfd,(struct sockaddr *)&addr,sizeof(addr))<0)
    {
    	perror("connecting error ");
    	exit(0);
    }
    else
    	cout<<"\nconnecting..."<<endl;
   /*perform to send & receiving data object*/
    while(true)
    {
            
            cout<<"\nEnter the message :";
            cin>>buff;
            
            if(send(sockfd,buff,strlen(buff),0)<0)//sending the object
            {
            	perror("error in sending.");
            	exit(0);
            }

            if(read(sockfd,buff,80)<0)//receiving the object
            {
            	perror("error in receving");
            	exit(0);
            }
            else if(strcmp(buff,"exit")==0)//checking exit status
            {
            	exit(0);
            }
            else
            	cout<<"\nFrom server :"<<buff<<endl;

            memset(buff,'\0',sizeof(buff));
    }

 return 0;
}