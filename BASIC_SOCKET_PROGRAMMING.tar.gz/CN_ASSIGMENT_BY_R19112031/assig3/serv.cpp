/*required header files*/
using namespace std;
#include <iostream>
#include<string>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include<netdb.h>
/*creating and initilize socket*/
void connecting(string port){
   /*declaration of variable*/
   sockaddr_in addr;
   int sockfd,new_child;
   char buff[80];
   /*creating socket*/
   if((sockfd = socket(AF_INET,SOCK_STREAM,0))<0)
   {
   	perror("error opening socket...");
   	exit(0);
   }
   else
   	cout<<"\nsocket succesfuly created.";
   /*assing the proper protocol to structure*/
   addr.sin_family = AF_INET;
   addr.sin_port = htons(atoi(port.c_str()));
   addr.sin_addr.s_addr = htonl(INADDR_ANY);
   /*bind the created socket*/
   if(bind(sockfd,(struct sockaddr*)&addr,sizeof(addr))<0)
   {
   	perror("error to bind");
   	exit(0);
   }
   else
   	cout<<"\nsocket successfuly bind.";
   /*listening the client connection*/
   if(listen(sockfd,5)<0)
   {
   	perror("error in listening.");
   	exit(0);
   }
   else
   	cout<<"\nsocket successfuly listening..."<<endl;
   /*accept client connection & checking connection done or not*/
   socklen_t len = sizeof(addr);
   if((new_child = accept(sockfd,(struct sockaddr *)&addr,&len))<0)
   {
   	perror("error in accepting connection...");
   } 
       /*perform read and send operation*/
        while(true)
        {
        	memset(buff,'\0',80);//claer buff array
        	if(read(new_child,buff,80)<0)
        	{
        		perror("receving error.");
        		exit(0);
        	}
        	  if(strcmp(buff,"exit") == 0)
        	  {

                 if(send(new_child,"exit",5,0)<0)//sending exit status
                 	perror("error to sending");

                 exit(0);
        	  }
            /*sending other than exit message*/
        	  cout<<"\nFrom client : "<<buff;
            cout<<"\nTo client :";
            cin>>buff;
            if(send(new_child,buff,strlen(buff),0)<0)
            {
            	perror("error to sending .");
            	exit(0);
            }

        }

}

/*driver code*/
int main(int argc, char const *argv[])
{
	system("clear");

	if(argc!=2)//checking the command line argument
	{
		cout<<"use "<<argv[0]<<" <port>";
		exit(0);
	}

	connecting(argv[1]); // try to connect client
	
	return 0;
}