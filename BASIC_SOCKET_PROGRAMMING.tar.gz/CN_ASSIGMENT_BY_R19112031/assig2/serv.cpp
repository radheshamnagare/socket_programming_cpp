/*required header files*/
using namespace std;
#include<iostream>
#include<string>
#include<cstdio>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
/*server class for initilize and create socket*/
class server{
  /*declaration of variables*/
  private :
    struct sockaddr_in addr,c_addr;
    int sock,new_sock;
    char buff[80];

  public :

   server(string port){// server constructor
     sock = 0;
     init(port);
   }  
   /*creating socket*/
   void init(string port)
   {
   	   /*creating socket*/
        sock = socket(AF_INET,SOCK_STREAM,0);
       if(sock<0)
        perror("error to opening socket");
       else
        printf("\nconnecting...");
      /*assing the proper protocol structure member*/
       addr.sin_family = AF_INET;
       addr.sin_addr.s_addr = htonl(INADDR_ANY);
       addr.sin_port = htons(atoi(port.c_str()));
        /*bind the created socket*/   
        if(bind(sock,(struct sockaddr *)&addr,sizeof(addr))<0)
        {
          perror("error to bind");
        }   
        /*listening the client connection*/
        if(listen(sock,5)<0){
          perror("error to listening...");
        }
        else
          cout<<"listening ...";
        /*checking & accepting connection*/ 
        socklen_t len =sizeof(addr);
        new_sock = accept(sock,(struct sockaddr *)&addr,&len);
        if(new_sock<0){
          perror("error to accepting connection.");
          exit(0);
        }

         connecting();
   }
     /*perform sending & receiving operation*/
     void connecting()
     {

          while(1)
          {
            memset(buff,'\0',sizeof(buff));//clear buffer array
              read(new_sock,buff,80);//receiving object from client
              printf("\nFrom clien : %s",buff); 
                     if(strcmp(buff,"Bye")==0)
                     {
                      if(send(new_sock,"Good-Bye",8,0)<0)//replay to client
                        perror("sending error message.");

                     }
                     else
                     {
                      if(send(new_sock,"ok",8,0)<0)//replay to client
                        perror("sending error message.");
                     }     
                 
          }
     }

};
/*driver code*/
int main(int argc, char const *argv[])
{
	

	system("clear");  
       
       if(argc!=2)//checking command line argument
       {
       	printf("use %s <port> ",argv[0]);
       	exit(0);
       }	

       server s(argv[1]);  // construct socket & try to connect client

return 0;
}