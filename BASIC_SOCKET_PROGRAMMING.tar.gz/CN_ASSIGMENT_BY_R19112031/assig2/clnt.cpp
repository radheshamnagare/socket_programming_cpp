/*requied header files*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include<netdb.h>

/*driver code*/
int main(int argc, char const *argv[])
{
	/*declaration of variabel*/
	struct sockaddr_in addr;
	struct hostent *host;
	int sock;
	char buff[80];
	system("clear");
       
       if(argc!=3)//checking command line argument
       {
       	printf("use %s <port> <host>",argv[0]);
       	exit(0);
       }
       /*creating socket*/
       if((sock = socket(AF_INET,SOCK_STREAM,0))<0){
       	perror("\nerror opening socket..");
       	exit(0);
       }
       /*assing proper protocol to structure member*/
       addr.sin_family = AF_INET;
       addr.sin_port = htons(atoi(argv[1]));//port no
       host = gethostbyname(argv[2]);//hostname in string formate
      /*checking host is valid or not*/
       if(host == NULL)
       	perror("invalid host");
       /*try to connect server*/
       if(connect(sock,(struct sockaddr *)&addr,sizeof(addr))<0)
       {
       	perror("error to connect");
        exit(0); 
       }
       /*sending & receiving object*/
       while(1)
       {
          printf("\nEnter the message :");
          scanf("%s",buff);

          if(send(sock,buff,strlen(buff),0)<0)//sending string
          {
          	perror("error to sending ...");
          	exit(0);
          }      
          memset(buff,'\0',sizeof(buff));  //clear buffer object
          if(read(sock,buff,sizeof(buff))<0)//receiving message from server
          {
          	perror("error to receving ...");
          	exit(0);
          }

          printf("\nFrom server : %s",buff);//printing receiving data
          
       }

return 0;
}