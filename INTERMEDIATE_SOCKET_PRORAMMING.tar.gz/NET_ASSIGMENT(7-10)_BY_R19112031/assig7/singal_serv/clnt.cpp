/*required header files*/
using namespace std;
#include<stdio.h>
#include <iostream>
#include<string>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include<netdb.h>


/*connecting() for initilize & create socket*/
void connecting(string port,string host)
{
    /*declaration of variable*/
	struct sockaddr_in addr;
	struct hostent *hostname;
	int sockfd;
	int ch,p,q,res,opt = 1;
    char buff[80];
    /*creating the socket*/
	if((sockfd = socket(AF_INET,SOCK_STREAM,0))<0)
	{
		perror("error to opening socket");
		exit(0);
	}
    /*assing proper protocol to structure member*/
	addr.sin_family = AF_INET;
	addr.sin_port = htons(atoi(port.c_str())); //port no
    hostname = gethostbyname(host.c_str()); // host name in string formate
    /*checking hostname is valid or not */
    if(hostname == NULL)
    {
    	perror("invalid host");
    	exit(0);
    }

           
     /*try to connect to server also checking connection done or not*/
    if(connect(sockfd,(struct sockaddr *)&addr,sizeof(addr))<0)
    {
    	perror("connection error");
    	exit(0);
    }
    /*to perform basic operation like receving & sending data*/
    
         while(true)
         {
             memset(buff,'\0',sizeof(buff));
             cout<<"\nEnter the expresion :";
             cin>>buff;
                if(strcmp(buff,"exit") == 0)
                {
                	if(write(sockfd,buff,sizeof(buff))<0)
                		perror("error to sending");
                	exit(0);
                }
             if(write(sockfd,buff,sizeof(buff))<0)
                perror("error to write");
              
             if(read(sockfd,&res,sizeof(int))<0)
                perror("error to reading");

             cout<<"\nResult :"<<res<<endl;
         } 

         close(sockfd); 	     
    
}
/*driver code*/
int main(int argc, char const *argv[])
{
	system("clear");

    if(argc!=3)//checking command line argument
    {
    	cout<<"use "<<argv[0]<<" <port> <host>";
    	exit(0);
    }

    connecting(argv[1],argv[2]); // try to connecting connection with port and host

return 0;
}