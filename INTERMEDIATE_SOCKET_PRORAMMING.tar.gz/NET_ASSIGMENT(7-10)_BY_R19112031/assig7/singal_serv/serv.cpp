/*required header files*/
using namespace std;
#include <iostream>
#include<string>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include<netdb.h>

int t_conn = 0;

/*server class for perform basic server socket operation*/
class server
{
   /*declaration of variable*/
   private:
      sockaddr_in addr;
      int sockfd,child;  
      char buff[80];
      int res,opt;
        /*declaration of template type of structure*/
      template <class x>
      struct expresion{
        x value;
        struct expresion *next;
      };
     /*creating two different object of structure*/
      struct expresion <string> *ob1;
      struct expresion <char> *ob2; 
   
   public :
         /*construtor of server class for initilizing & calling other function*/
         server(string port)
         {
          sockfd =0;
          res = 0;
          opt = 1;
          t_conn = 0;
          init(&ob1);
          init(&ob2);
          init_server(port);
         }
         /*init() for initilize object to null*/
         template <class x>
         void init(x **h){
          *h = NULL;
         }
     
      /*creating link list as stack*/
      template <class x,class y>
      void push(x **h,y v){
       x *t;
       x *N;
       N = new x;
       N->next = NULL;
       N->value = v;
          if(*h == NULL){
            *h = N;
          } 
          else
          {
             N->next = *h;
             *h = N;
          }
          
      }
     /*poping element from stack*/
      template <class x> 
      x *  pop(x **h){
        x *N,*P;   
           if(*h==NULL)
            {
              *h = NULL;
              return NULL;
            }
            else
            {
               P = N = *h;
               N = N->next;
               *h = N;
            }
         return P;    
      }
         /*init() for creating & initilization of socket*/
         void init_server(string port)
         {
            /*creating socket*/
            if((sockfd = socket(AF_INET,SOCK_STREAM,0))<0)
            {
              perror("error to creating socket...");
              exit(0);
            }
            else
              cout<<"\nsocket succesfully created"<<endl;

            /*assing the proper protocol to server*/
            addr.sin_family = AF_INET;
            addr.sin_port = htons(atoi(port.c_str()));
            addr.sin_addr.s_addr = htonl(INADDR_ANY);
            /*bind the created socket*/
            if(bind(sockfd,(struct sockaddr *)&addr,sizeof(addr))<0)
            {
              perror("error to bind.");
              exit(0);
            }
            /*listening the client connection*/
             if(listen(sockfd,1)<0)
             {
              perror("error to listen");
              exit(0);
             }
             else
              cout<<"\nlistening ..."<<endl;
        
             connect();//connect() for basic sending & receiving object
         }
          /*connect() for send & receiving object*/
         void connect()
         {

                 	
                 
             while(true)
             {
           
                /*accept the client connection*/
              socklen_t len = sizeof(addr);
             if((child = accept(sockfd,(struct sockaddr *)&addr,&len))<0)
             {
              perror("error to connect");
              exit(0);
             }   
                 
                if(child>0)
                {
                	if(t_conn>1)
                	{
                		close(child);
                		
                	}
                	else
                		t_conn+=1;
                }
                  if(read(child,buff,sizeof(buff))<0)
                  perror("error to reading");

                 if(strcmp(buff,"exit") == 0)
                 {
                     close(child);
                     close(sockfd);
                     exit(0);
                 }

                 res = stoi(evaluate(buff));
                 if(write(child,&res,sizeof(int))<0)
                   perror("errot to write");
                 
             }

         }
        /*evaluate the expresion e.g (800*7+(8+5))*/ 
      string evaluate(string buff)
      {
         string no;
          for(int i=0;i<buff.size();i++){
               if(isdigit(buff[i]))
               {
                 no+=buff[i];
               }
               else if(buff[i] == '(')
               {
                push(&ob2,buff[i]);
               }
               else if(buff[i] == ')')
               {
                 push(&ob1,no);
                 no.clear();
                 string no1 = pop(&ob1)->value;
                 string no2 = pop(&ob1)->value;
                 char ch = pop(&ob2)->value;
                   
                    while(ch!='(')
                    {
                             if(ch == '+')
                             {
                               res = stoi(no2)+stoi(no1);
                             }
                             else if(ch == '-')
                             {
                                res = stoi(no2)-stoi(no1);
                             }
                             else if(ch == '*')
                             {
                               res = stoi(no2)*stoi(no1);
                             }
                             else if(ch == '/')
                             {
                               res = stoi(no2)/stoi(no1);
                             }
                             no = to_string(res);
                             ch = pop(&ob2)->value;
                             push(&ob1,no);
                    }


               }
               else if(buff[i] == '+'||buff[i] == '-'|| buff[i] == '*'||buff[i] == '/')
               {
                  
                   push(&ob1,no);
                   push(&ob2,buff[i]);  
                   no.clear();
               }   
          }
           
           return pop(&ob1)->value;

      }

};
/*driver programm*/
int main(int argc, char const *argv[])
{
  
  system("clear");
     if(argc!=2)//checking command line argument
     {
       cout<<"use "<<argv[0]<<" <port>";
       exit(0);
     }
    server s(argv[1]);// try to accept server connection 

  return 0;
}