using namespace std;
#include<iostream>

//required variable
int res = 0;
string no;

/*template type structure*/
 template <class x>
 struct expresion{
    x value;
    struct expresion *next;
 };
  /*required two different type of object*/
 struct expresion <string> *ob1;
 struct expresion <char> *ob2;
/*template type of init() to initilize to null*/
 template <class x>
 void init(x **h){
   *h = NULL;
 }
     
/*push() creating link list as stack*/      
template <class x,class y>
void push(x **h,y v){
       x *t;
       x *N;
       N = new x;
       N->next = NULL;
       N->value = v;
          if(*h == NULL){
            *h = N;
          } 
          else
          {
             N->next = *h;
             *h = N;
          }
          
}
/*pop() poping element in the list*/     
template <class x> 
x *  pop(x **h){
        x *N,*P;   
           if(*h==NULL)
            {
              *h = NULL;
              return NULL;
            }
            else
            {
               P = N = *h;
               N = N->next;
               *h = N;
            }
         return P;    
 } 
/*evaluate the expresion e.g ((10+7)+2)*/
string evaluate(string buff)
{
	init(&ob1);
	init(&ob2);

         string no;
          for(int i=0;i<buff.size();i++){
               if(isdigit(buff[i]))
               {
                 no+=buff[i];
               }
               else if(buff[i] == '(')
               {
                push(&ob2,buff[i]);
               }
               else if(buff[i] == ')')
               {
                 push(&ob1,no);
                 no.clear();
                 string no1 = pop(&ob1)->value;
                 string no2 = pop(&ob1)->value;
                 char ch = pop(&ob2)->value;
                   
                    while(ch!='(')
                    {
                             if(ch == '+')
                             {
                               res = stoi(no2)+stoi(no1);
                             }
                             else if(ch == '-')
                             {
                                res = stoi(no2)-stoi(no1);
                             }
                             else if(ch == '*')
                             {
                               res = stoi(no2)*stoi(no1);
                             }
                             else if(ch == '/')
                             {
                               res = stoi(no2)/stoi(no1);
                             }
                             no = to_string(res);
                             ch = pop(&ob2)->value;
                             push(&ob1,no);
                    }


               }
               else if(buff[i] == '+'||buff[i] == '-'|| buff[i] == '*'||buff[i] == '/')
               {
                  
                   push(&ob1,no);
                   push(&ob2,buff[i]);  
                   no.clear();
               }   
          }
           
           return pop(&ob1)->value;

}

