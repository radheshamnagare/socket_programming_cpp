/*required header files*/
using namespace std;
#include <iostream>
#include<string>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include<sys/select.h>
#include<netdb.h>




/*server class for perform basic server socket operation*/
class server
{
   /*declaration of variable*/
   private:
   	  
      sockaddr_in addr;
      int sockfd,child;  
      int res;
   public :
         /*construtor of server class for initilizing & calling other function*/
         server(string port)
         {

          sockfd =0;
          init_server(port);
         }

         
         
         void init_server(string port)
         {
            /*creating socket*/
            if((sockfd = socket(AF_INET,SOCK_STREAM,0))<0)
            {
              perror("error to creating socket...");
              exit(0);
            }
            else
              cout<<"\nsocket succesfully created"<<endl;
            /*assing the proper protocol to server*/
            addr.sin_family = AF_INET;
            addr.sin_port = htons(atoi(port.c_str()));
            addr.sin_addr.s_addr = htonl(INADDR_ANY);
            /*bind the created socket*/
            if(bind(sockfd,(struct sockaddr *)&addr,sizeof(addr))<0)
            {
              perror("error to bind.");
              exit(0);
            }
            /*listening the client connection*/
             if(listen(sockfd,5)<0)
             {
              perror("error to listen");
              exit(0);
             }
             else
              cout<<"\nlistening ..."<<endl;
        
             connect();//connect() for basic sending & receiving object
         }
          
 
void connect(){

socklen_t cliLen=sizeof(addr);
int fds[16];
fd_set rfds;
int fdcap=16;
int fdlen=0;
int maxfd;
char recvBuf[2048];
int bufLen=sizeof(recvBuf);
int recvLen=0;

while(1)
   {
   	  
      memset(recvBuf,'\0',bufLen);
      FD_ZERO(&rfds);
      FD_SET(sockfd,&rfds);
      int x=0;
      maxfd=sockfd;
         for(x=0;x<fdlen;x++)
         {
           FD_SET(fds[x],&rfds);
           if(maxfd<fds[x])
              maxfd=fds[x];
         }
      if(select(maxfd+1,&rfds,NULL,NULL,NULL)<=0)
      {
      	perror("error timeout connection:");
      	exit(0);
      }
      if(FD_ISSET(sockfd,&rfds))
      {
          
          int childfd=accept(sockfd,(struct sockaddr *)&addr,&cliLen);
          if(childfd<0)
          {
           perror("\n Error in accept");
           continue;
          }
        
          if(fdlen==fdcap)
          {
           close(childfd);
          }
          else
          {
           fds[fdlen]=childfd;
           fdlen++;
          }
      }
      else
      {
         int childfd=0;
         for(x=0;x<fdlen;x++)
         {
            if (!FD_ISSET(fds[x],&rfds))
            continue;
            childfd=fds[x];
            if((recvLen=recv((childfd),recvBuf,bufLen,0))<0)
            {
             perror("\n error in recieve");
             FD_CLR(childfd,&rfds);
             fds[x]=fds[fdlen-1];
             fdlen--;
             break;
            }
           if(recvLen==0)
           {
             close(childfd);
             FD_CLR(childfd,&rfds);

              fds[x]=fds[fdlen-1];
              fdlen--;
              printf("closing...\n");
              exit(0);
              break;
           }
           recvBuf[recvLen]='\0';
            
           
          if(write(childfd,recvBuf,strlen(recvBuf))<0)
          {
            perror("\n error in sending");
           continue;
          }

        }
      }


   }

 }


};
/*driver programm*/
int main(int argc, char const *argv[])
{
  
  system("clear");
     if(argc!=2)//checking command line argument
     {
       cout<<"use "<<argv[0]<<" <port>";
       exit(0);
     }
    server s(argv[1]);// try to accept server connection 

  return 0;
}