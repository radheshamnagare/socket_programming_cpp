using namespace std;
#include <arpa/inet.h> 
#include <netinet/in.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <strings.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include<unistd.h>
#include<string>
#define PORT 5000 
#define MAXLINE 1024

int main() 
{ 
	int sockfd; 
	char buffer[MAXLINE]; 
	string message = "Hello Server"; 
	struct sockaddr_in servaddr; 
    socklen_t len;
	int n; 
	// Creating socket file descriptor 
	if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) { 
		printf("socket creation failed"); 
		exit(0); 
	} 

	

	// Filling server information 
	servaddr.sin_family = AF_INET; 
	servaddr.sin_port = htons(PORT); 
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1"); 

	len = sizeof(servaddr);
	// send hello message to server 
	sendto(sockfd, message.c_str(), message.size(), 
		0, (const struct sockaddr*)&servaddr, 
		sizeof(servaddr)); 

	// receive server's response 
	while(1){
	printf("Message from server: "); 
	n = recvfrom(sockfd, (char*)buffer, MAXLINE, 
				0, (struct sockaddr*)&servaddr, 
				&len); 
	puts(buffer); 

   }
	close(sockfd); 
	return 0; 
} 
